import './Navbar.css'
import { Phone, SlidersHorizontal } from "lucide-react"

export const Navbar = () => {
    return (<>
        <section className='navbar'>
            <div className='navbar-case'>
                <div className='filter-section'>
                    <h1 className='logo-name'>EURO <span>CARS</span></h1>
                    <button className='button-filter'><SlidersHorizontal className='filter-icon'></SlidersHorizontal></button>
                </div>

                <div className='navbar-characteristics'>
                    <div className='characteristics'>
                        <a href='#home'>Home </a>
                        <a href='#catalog'>Catalog </a>
                        <a href='#services'>Services </a>
                        <a href='#aboutas'>About as </a>
                        <a href='#contacts'>Contacts </a>
                        <div className='Request-a-call'>
                            <button >Замовити дзвінок </button>
                        </div>
                    </div>
                </div>

            </div>



            {/* <section className='contact-section'>
                <Phone className='Phone-icon'></Phone>
                <p>Phone</p>
                <p>Adress</p>

            </section>
            <div className='firm-contact'> 0663048826
            </div>
            <div className='language-choose'>

            </div> */}


        </section>

    </>)
}