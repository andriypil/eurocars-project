import { Home } from '../components/home/Home'
import { Catalogs } from '../components/catalog/Catalogs'
import { Services } from '../components/servics/Services'
import { AboutAs } from '../components/about-as/AboutAs'
import { Contacts } from '../components/contacts/Contacts'
import { BrowserRouter, Routes, Route } from 'react-router-dom'



export const Home_page = () => {
    return (<>
        <Home></Home>
        <Catalogs></Catalogs>
        <Services></Services>
        <AboutAs></AboutAs>
        <Contacts></Contacts>



    </>)
}