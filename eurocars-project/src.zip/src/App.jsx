import { useState } from 'react'
import { Navbar } from './components/navbar/Navbar'

import { BrowserRouter, Routes, Route } from 'react-router-dom'

import { Catalog } from './catalog-cars/Catalog'

import './App.css'
import { Phone } from "lucide-react"
import { Home_page } from './home_page/Home_page'



function App() {
  const [count, setCount] = useState(0)

  return (
    <>

      <BrowserRouter>
        <main className='main-container '>
          <Navbar></Navbar>

          <Routes>
            <Route element={<Catalog></Catalog>} path='/catalog'></Route>
            <Route element={<Home_page></Home_page>} path='/'></Route>

          </Routes>




        </main>
      </BrowserRouter>
    </>

  )


}

export default App
