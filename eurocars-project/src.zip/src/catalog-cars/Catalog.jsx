export const Catalog = () => {
    return (<>
        <section className="Catalog">
            <p>erlfbkejrfgilash</p>
        </section>

    </>)
}