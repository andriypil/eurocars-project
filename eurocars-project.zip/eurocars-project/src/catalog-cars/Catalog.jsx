import { Sidebar } from '../componetsCatalog/sidebar/Sidebar'
import { Unfavorite } from '../componetsCatalog/unfavorite/Unfavorite'

export const Catalog = () => {
    return (<>
        <Sidebar></Sidebar>
        <Unfavorite></Unfavorite>

    </>)
}