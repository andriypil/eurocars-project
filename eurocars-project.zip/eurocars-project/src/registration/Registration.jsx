export const Registration = () => {
    return (<>
        <section className="Registration">
            <p>erlfbkejrfgilash</p>
        </section>

    </>)
}