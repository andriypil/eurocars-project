import './Unfavorite.css'

import { Car, Fuel, CalendarFold, Heart, Eye, Facebook, Twitter, Instagram, ChevronRight, ChevronLeft } from "lucide-react";

export const Unfavorite = () => {
    return (<>
        <section className='Unfavorite'>
            <div className='unfavorite-cards'>
                <div className='deception'></div>

                <div className='unfavorite-car-card'>
                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>





                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>





                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>





                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>






                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className='unfavorite-car-card-2'>

                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div className='wer'>
                        <div className='car-cards-button '>
                            <div className='car-cards-button-object'>
                                <button><Heart></Heart></button>
                                <button><Eye></Eye></button>
                            </div>
                        </div>

                        <div className='car-cards-top'>
                            <div className='top-cards-for-cars-meaning'>
                                <h1>Bugatti Chiron Pur Sport </h1>
                                <h1>3 000 000 євро</h1>
                                <div className='cross-section-line'></div>

                                <div className='machine-characteristics'>

                                    <div className='characteristic'><Car></Car>5 000 km</div>
                                    <div className='characteristic'><Fuel></Fuel>бензин</div>
                                    <div className='characteristic'><CalendarFold></CalendarFold>2024 рік</div>

                                </div>

                                <div className='car-descriptions'>
                                    <div className='options-description'>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                        <div className='descriptions'>опції</div>
                                    </div>
                                </div>

                                <div className='moredetails-contact'>
                                    <div className='options-moredetails-contact'>
                                        <button className='moredetails'>Детальніше</button>
                                        <button className='get-in-touch'>Зв'язатися</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div className='footer'>
                        <div className='pagination-container'>
                            <button className='pagination-arrow'><ChevronLeft size={54} /></button>
                            <button className='pagination-number active'>1</button>
                            <button className='pagination-number'>2</button>
                            <button className='pagination-number'>3</button>
                            <span className='pagination-dots'>...</span>
                            <button className='pagination-number'>4</button>
                            <button className='pagination-arrow'><ChevronRight size={54} /></button>
                        </div>




                        <footer className='euro-footer'>
                            <div className='footer-content'>
                                <div className='footer-brand'>
                                    <div className='footer-h2'>
                                        <h2>< div className='white'>EURO </div> <samp>CARS</samp></h2>
                                    </div>
                                    <p>Преміальне авто із Європи</p>
                                </div>
                                <div className='footer-socials'>

                                    <a href="#" aria-label="Facebook"><Facebook /></a>
                                    <a href="#" aria-label="Twitter"><Twitter /></a>
                                    <a href="#" aria-label="Instagram"><Instagram /></a>

                                </div>
                            </div>

                            <div className='footer-lines'></div>

                            <div className='footer-bottom-bar'>
                                <p>© 2025 EUROCARS. Всі права захищені.</p>
                                <div className='footer-links'>
                                    <a href="#">Політика конфіденційності</a>
                                    <a href="#">Правова інформація</a>
                                </div>
                            </div>
                        </footer>
                    </div>
                </div>
            </div>
        </section >



    </>)
}